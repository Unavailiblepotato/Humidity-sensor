<img src='icon.svg' style="height:80px;">

# One Dark Pro

> Atom's iconic One Dark theme for Visual Studio Code

- Atom's iconic One Dark theme, but much better!
- Make your Visual Studio Code sexier!
- Open-source!

[GitHub](https://github.com/Binaryify/OneDark-Pro)
[Get Started](#About)

![color](#ffffff)
