#ifdef NON_ARDUINO
#include <non_arduino_adaptations.h>
SerialClass Serial;
#endif 
