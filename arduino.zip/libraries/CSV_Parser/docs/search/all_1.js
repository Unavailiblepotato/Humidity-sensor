var searchData=
[
  ['documentation_5fconfig_2etxt_4',['documentation_config.txt',['../documentation__config_8txt.html',1,'']]]
];
